const arrayClientes = [];
const arrayCuentas =[];
let posicionActual = 0;

function crearCliente() {
  let clienteNombre = prompt("Dime el nombre del cliente:");
  let clienteApellido = prompt("Dime el apellido del cliente:");
  let clienteDni = prompt("Dame el DNI del cliente:");
  let cliente = new Clientes(clienteDni, clienteNombre, clienteApellido);
  arrayClientes.push(cliente);
 // console.log("el cliente es", cliente);
  posicionActual = arrayClientes.length - 1;
  clienteDni = arrayClientes[posicionActual].dni;
  clienteNombre = arrayClientes[posicionActual].nombre;
  clienteApellido = arrayClientes[posicionActual].apellido;
  alert (cliente);


  /*function crearCuenta(){
    let cuentaNumber = prompt("Dime el numero de cuenta:");
    let cuenta = new cuenta (cuentaNumber);
    arrayCuentas.push(cuenta);
    posicionActual = arrayCuentas-length-1;
    cuentaNumber = arrayCuentas[posicionActual].numeroCuenta
   
  }*/
}
