let arrayPersonas = [
    new Persona("Paco Pérez", 70, 175),
    new Persona("María Robles", 68, 168),
    new Persona("Isabel Villa", 58, 160),
    
];
console.table(arrayPersonas);
