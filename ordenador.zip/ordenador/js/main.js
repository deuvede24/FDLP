
function crearOrdenadores() {
  let ordenadorMarca1 = prompt("Dime la marca del ordenador");
  let ordenadorModelo1 = prompt("Dime el modelo del ordenador");
  let ordenadorProcesador1 = prompt("Dime el tipo de procesador");
  let ordenadorMemoria1 = prompt("Introduce el valor de la memoria RAM");
  let ordenadorCapacidad1 = prompt("Introduce el la capaciad del disco duro");
  let compu1 = new Ordenador(ordenadorMarca1, ordenadorModelo1, ordenadorProcesador1, ordenadorMemoria1, ordenadorCapacidad1);
  console.log(compu1);

  let ordenadorMarca2 = prompt("Dime la marca del ordenador");
  let ordenadorModelo2 = prompt("Dime el modelo del ordenador");
  let ordenadorProcesador2 = prompt("Dime el tipo de procesador");
  let ordenadorMemoria2 = prompt("Introduce el valor de la memoria RAM");
  let ordenadorCapacidad2 = prompt("Introduce el la capaciad del disco duro");
  let compu2 = new Ordenador(ordenadorMarca2, ordenadorModelo2, ordenadorProcesador2, ordenadorMemoria2, ordenadorCapacidad2);

  console.log(ordenadorCapacidad1);
  console.log(ordenadorMarca1);
  console.log(ordenadorModelo1);
  console.log(ordenadorMemoria1);
  console.log(ordenadorProcesador1)


  let compu1Es = compu1.toString();
  alert(compu1Es);
  let compu2Es = compu2.toString();
  alert(compu2Es);

}









